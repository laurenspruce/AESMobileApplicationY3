package com.example.aesapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {

    //Declaring the variables
    EditText inputText, inputPassword;
    TextView outputText;
    Button encodeButton, decodeButton;
    String outputString;
    String AES = "AES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Linking variables to text fields and buttons
        inputText = (EditText) findViewById(R.id.inputText); //Linking the input text field
        inputPassword = (EditText) findViewById(R.id.password); //Linking the password text field

        outputText = (TextView) findViewById(R.id.outputText); //Linking the output text field
        encodeButton = (Button) findViewById(R.id.encryptButton); //Linking the encrypt button
        decodeButton = (Button) findViewById(R.id.decryptButton); //Linking the decrypt button

        //This is the functionality of the encode button
        encodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //When the user interacts with the button it will perform a try and catch to encrypt the initial text entered
                try {
                    outputString = encrypt(inputText.getText().toString(), inputPassword.getText().toString()); //To take the initial text entered and the password inputted by the user
                    outputText.setText(outputString); //This set's the text to the output of the encryption
                } catch (Exception exception) { //Exception handler, to define the code to be executed
                    exception.printStackTrace(); //For handling exceptions and errors within the try
                }
            }
        });

        //This is the functionality of the decode button
        decodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //When the user interacts with the button it will perform a try and catch to decrypt the encrypted text produced
                try {
                    outputString = decrypt(outputString,inputPassword.getText().toString()); //This checks the input password
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Incorrect Password entered", Toast.LENGTH_SHORT).show(); //To display a small message box alerting the user the wrong password has been entered
                    e.printStackTrace(); //For handling exceptions and errors within the try
                }
                outputText.setText(outputString); //This will set the decrypted text back to the initial text in the output text box
            }
        });
    }

    //This is the decryption method
    private String decrypt(String outputString, String password) throws Exception{ //Takes the string and password as variables to complete decryption
        SecretKeySpec key = generateKey(password); //Generates a secret spec key
        Cipher c = Cipher.getInstance(AES); //Creating a cipher to get the instance of AES
        c.init(Cipher.DECRYPT_MODE, key); //initialise cipher object to decryption mode
        byte[] decodedValue = Base64.decode(outputString, Base64.DEFAULT); //Decoding binary values to string
        byte[] decValue = c.doFinal(decodedValue);
        String decryptedValue = new String(decValue);
        return decryptedValue; //Returning the decrypted value
    }

    //This is the encryption method
    private String encrypt(String Data, String password) throws Exception { //Takes the string and password as variables to complete encryption
                SecretKeySpec key = generateKey(password); //Generates a secret spec key
                Cipher c = Cipher.getInstance(AES); //Creating a cipher to get the instance of AES
                c.init(Cipher.ENCRYPT_MODE,key); //initialise cipher object to encryption mode
                byte[] encVal = c.doFinal(Data.getBytes());
                String encryptedValue = Base64.encodeToString(encVal, Base64.DEFAULT); //Encoding binary values to string
                return encryptedValue; //Returning the encrypted value
     }

     //This method is to generate keys
     private SecretKeySpec generateKey(String password) throws Exception {
        //Message direct is used to create a one way hash
        final MessageDigest digest = MessageDigest.getInstance("SHA-256"); //Creating the key size of 256-bits
        byte[] bytes = password.getBytes("UTF-8"); //Converting the password into bytes
        digest.update(bytes, 0, bytes.length); //Updates digest using specified array of bytes
        byte[] key = digest.digest(); //Completing the digest
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES"); //Creating a new key using the AES algorithm
        return secretKeySpec; //Returns the secret key
     }

}